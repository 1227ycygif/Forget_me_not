﻿#define DEBUG_MODE

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum MirrorState
{
    RightUp,
    RightDown,
    LeftDown,
    LeftUp
}

[RequireComponent(typeof(PhotonView))]

public class csMirror : MonoBehaviour
{
    // 포톤
    PhotonView pv;

    // 거울의 상태를 저장하는 변수
    public MirrorState mirrorState;

    // 초기 각도용 변수, 쓸려면 쓰고
    Quaternion origin = Quaternion.EulerAngles(0, 45, 0);

    Quaternion targetAngle;             // 타겟 각도


    private void Awake()
    {
        pv = GetComponent<PhotonView>();
        SetTarget();
    }

    // Update is called once per frame
    void Update()
    {
        transform.rotation = targetAngle;
        SetTarget();
    }

    // 거울을 똘리기 위해 외부에서 호출, RPC 호출
    public void TurnOnce()
    {
#if DEBUG_MODE
        RotateNext();
#else
        // 이건 버튼을 누가 눌러서 호출했든, 버튼이 눌렸다면 모두 다 돌아야하므로
        pv.RPC("RotateNext", PhotonTargets.All, null);
#endif
    }

    [PunRPC]
    void RotateNext()
    {
        // 거울 상태 변경
        mirrorState = (mirrorState == MirrorState.LeftUp) ? 0 : mirrorState + 1;

        // 상태 변수를 기반으로 회전각 설정
        SetTarget();
    }

    void SetTarget()
    {
        // 상태 변수를 기반으로 회전각 설정
        switch (mirrorState)
        {
            case MirrorState.RightUp:
                targetAngle = Quaternion.Euler(new Vector3(0, 45, 0));
                break;
            case MirrorState.RightDown:
                targetAngle = Quaternion.Euler(new Vector3(0, 135, 0));
                break;
            case MirrorState.LeftDown:
                targetAngle = Quaternion.Euler(new Vector3(0, 225, 0));
                break;
            case MirrorState.LeftUp:
                targetAngle = Quaternion.Euler(new Vector3(0, 315, 0));
                break;
        }
    }
    
}
